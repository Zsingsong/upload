//
//  RootViewController.m
//  Navigation Controller Test
//
//  Created by MagicStudio on 12-4-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "MovieViewController.h"
#import "SongViewController.h"
#import "SingerViewController.h"
#import "SportViewController.h"

@implementation RootViewController

@synthesize controllerList;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.title = @"分类"; 
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    //电影 
    MovieViewController *movieViewController = [[MovieViewController alloc]
                                                initWithStyle:UITableViewStylePlain]; 
    movieViewController.title = @"电影";  
    [array addObject:movieViewController];
    
    //歌曲
    SongViewController *songViewController = [[SongViewController alloc]
                                                initWithStyle:UITableViewStylePlain]; 
    songViewController.title = @"歌曲";  
    [array addObject:songViewController];
    
    //歌手
    SingerViewController *singerViewController = [[SingerViewController alloc]
                                              initWithStyle:UITableViewStylePlain]; 
    singerViewController.title = @"歌手";  
    [array addObject:singerViewController];
    
    //运动
    SportViewController *sportViewController = [[SportViewController alloc]
                                                  initWithStyle:UITableViewStylePlain]; 
    sportViewController.title = @"运动";  
    [array addObject:sportViewController];
    
    self.controllerList = array;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self.controllerList = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [controllerList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *RootTableViewCell = @"RootTableViewCell"; 
    UITableViewCell *cell = [tableView
                             dequeueReusableCellWithIdentifier: RootTableViewCell]; 
    if (cell == nil) { 
        cell = [[UITableViewCell alloc] 
                initWithStyle:UITableViewCellStyleDefault
                reuseIdentifier: RootTableViewCell]; 
    } 
    NSUInteger row = [indexPath row]; 
    UITableViewController *controller = [controllerList objectAtIndex:row]; 
    cell.textLabel.text = controller.title;
    //accessoryType就表示每行右边的图标
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator; 
    return cell; 
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger row = [indexPath row]; 
    UITableViewController *nextController = [self.controllerList objectAtIndex:row]; 
    [self.navigationController pushViewController:nextController animated:YES]; 
}

@end
