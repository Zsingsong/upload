//
//  SongViewController.m
//  Navigation Controller Test
//
//  Created by MagicStudio on 12-4-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "SongViewController.h"
#import "SongDetailViewController.h"
#import "AppDelegate.h" 

@interface SongViewController () 
@property (strong, nonatomic) SongDetailViewController *childController; 
@end 

@implementation SongViewController

@synthesize songList;
@synthesize childController;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    NSArray *array = [[NSArray alloc] initWithObjects:@"黑色幽默", @"龙卷风",
                      @"星晴", @"爱在西元前", @"安静", @"开不了口", @"上海1943",
                      @"回到过去", @"暗号", @"半岛铁盒", @"分裂", @"东风破",
                      @"晴天", @"菊花台", @"千里之外", @"青花瓷", @"世界末日",
                      @"蜗牛", @"七里香", @"爱我别走", @"断了的弦", @"轨迹",
                      @"龙拳", @"你听的到", nil];
    self.songList = array;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self.childController = nil;
    self.songList = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [songList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *SongTableViewCell = @"SongTableViewCell"; 
    UITableViewCell *cell = [tableView
                             dequeueReusableCellWithIdentifier: SongTableViewCell]; 
    if (cell == nil) { 
        cell = [[UITableViewCell alloc] 
                initWithStyle:UITableViewCellStyleDefault
                reuseIdentifier: SongTableViewCell]; 
    } 
    NSUInteger row = [indexPath row]; 
    NSString *songTitle = [songList objectAtIndex:row];
    //这里设置每一行显示的文本为所对应的View Controller的标题
    cell.textLabel.text = songTitle;
    //accessoryType就表示每行右边的图标
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton; 
    return cell; 
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES]; 
}

- (void)tableView:(UITableView *)tableView
accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath { 
    if (childController == nil) { 
        childController = [[SongDetailViewController alloc]
                           initWithNibName:@"SongDetailViewController" bundle:nil]; 
    } 
    NSUInteger row = [indexPath row]; 
    NSString *selectedSong = [songList objectAtIndex:row]; 
    NSString *detailMessage = [[NSString alloc]
                               initWithFormat:@"你选择了歌曲：%@.", selectedSong]; 
    childController.message = detailMessage; 
    childController.title = selectedSong; 
    [self.navigationController pushViewController:childController animated:YES]; 
} 
@end
