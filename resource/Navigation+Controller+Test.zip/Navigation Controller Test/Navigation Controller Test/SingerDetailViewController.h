//
//  SingerDetailViewController.h
//  Navigation Controller Test
//
//  Created by MagicStudio on 12-4-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SingerDetailViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *detailLabel;
@property (copy, nonatomic) NSString *message;

@end
